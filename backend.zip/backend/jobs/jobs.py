from django.conf import settings
import json


def schedule_api():
    print("okey")
